# GP2_sum

Files:

- [GP提纲.pdf](GP提纲.pdf)
