# IBMS3 / detailed / from_yicheng

Files in `from_yicheng`:

- AI notes for seminar_yicheng.md
- Final notes for seminar_yicheng.md
- IBMS总结复习_yicheng.md
- MY notes for slides_yicheng.md
