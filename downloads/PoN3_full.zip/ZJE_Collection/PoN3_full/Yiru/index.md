# PoN3_full

Files and subfolders:

- [1.1 Introduction and Refresh.md](1.1 Introduction and Refresh.md)
- [1.2 Presynaptic release.md](1.2 Presynaptic release.md)
- [10.1, 2 Neurodegenerative disease.md](10.1, 2 Neurodegenerative disease.md)
- [10.2 Neurodegeneration disease- Parkinson's disease and Prion disease.md](10.2 Neurodegeneration disease- Parkinson's disease and Prion disease.md)
- [12.1 Brain and spinal cord of movement control.md](12.1 Brain and spinal cord of movement control.md)
- [13.2 Social neuroscience- Theory of mid, empathy, mirror neurons and aggression.md](13.2 Social neuroscience- Theory of mid, empathy, mirror neurons and aggression.md)
- [2.1 Long- term plasticity.md](2.1 Long- term plasticity.md)
- [2.2 Synaptic plasticity.md](2.2 Synaptic plasticity.md)
- [3.1 GABAergic inhibitory function.md](3.1 GABAergic inhibitory function.md)
- [3.2 Interneuron Diversity.md](3.2 Interneuron Diversity.md)
- [4.2 Learning and memory.md](4.2 Learning and memory.md)
- [5.1 Attention and emotion.md](5.1 Attention and emotion.md)
- [6.1 Rewards, punishment, reinforcement learning.md](6.1 Rewards, punishment, reinforcement learning.md)
- [6.2 Schemas and decision making.md](6.2 Schemas and decision making.md)
- [7.1 Neuroimaging.md](7.1 Neuroimaging.md)
- [7.2 Mood, habits, and addiction.md](7.2 Mood, habits, and addiction.md)
- [final_exam/](final_exam/)
