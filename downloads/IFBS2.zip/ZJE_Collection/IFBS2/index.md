# IFBS2

Files contributed:

- ZIP packages are hosted externally. See: [思维导图IFBS_lxr](../zip_contents/思维导图IFBS_lxr.md)

## External links

- Hal (2022-2023): https://drive.google.com/file/d/1lgH-OKJ_kiLtY1RT4h6Taky-VZNVfUoA/view?usp=sharing
