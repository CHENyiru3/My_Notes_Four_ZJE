# IBMS3_full / detailed

Files and subfolders in `detailed`:

- [一实验方法速查.md](一实验方法速查.md)
- [0. Model selection.md](0. Model selection.md)
- [1. Experiment Methods.md](1. Experiment Methods.md)
- [2. Group settings.md](2. Group settings.md)
- [4. Statistical analysis; Computational methods.md](4. Statistical analysis; Computational methods.md)
- [4.5 Visualization.md](4.5 Visualization.md)
- [5. Ethics.md](5. Ethics.md)
- [6. Critical thinking.md](6. Critical thinking.md)

Subfolders:

- [experiments_case/](experiments_case/)
- [from_yicheng/](from_yicheng/)
