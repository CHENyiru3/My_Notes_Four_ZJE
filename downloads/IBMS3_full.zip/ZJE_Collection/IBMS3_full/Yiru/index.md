# IBMS3_full

Files and subfolders:

- [一实验方法速查.pdf](一实验方法速查.pdf)
- [考前整理(1).pdf](考前整理%281%29.pdf)
- [Experimental Design & Ethics.pdf](Experimental Design & Ethics.pdf)
- [IBMS Dry Lab 答题总结.pdf](IBMS Dry Lab 答题总结.pdf)
- [IBMS Wet Lab 答题总结.pdf](IBMS Wet Lab 答题总结.pdf)

Subfolders:

- [detailed/](detailed/)
