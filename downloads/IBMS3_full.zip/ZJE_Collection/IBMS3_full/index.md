# IBMS3_full

## Contributors

- Yiru: [main materials](Yiru/index.md)
- Xiaoran_etal: [additional materials](Xiaoran_etal/)

## Files

- Browse Yiru materials: [Yiru/](Yiru/)
- Browse Xiaoran_etal materials: [Xiaoran_etal/](Xiaoran_etal/)
