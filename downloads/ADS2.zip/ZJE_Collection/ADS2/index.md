# ADS2 (Applied Data Science)

## Contributors

- Hal (2022-2023): External materials available

## Notes & Materials

*This course currently has limited materials. Contributions welcome!*

## External Resources

- [Hal's Materials (2022-2023)](https://drive.google.com/file/d/1Fl2WtzDZoyEqi3MLvilNCOUIeTbQTl-Y/view?usp=sharing)
