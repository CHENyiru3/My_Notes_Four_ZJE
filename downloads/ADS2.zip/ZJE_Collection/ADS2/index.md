# ADS2

## External links

- Hal (2022-2023): https://drive.google.com/file/d/1Fl2WtzDZoyEqi3MLvilNCOUIeTbQTl-Y/view?usp=sharing
