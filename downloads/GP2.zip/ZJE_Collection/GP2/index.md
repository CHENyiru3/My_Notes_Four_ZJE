# GP2

## Contributors

- Yiru: [notes and PDFs](Yiru/index.md)

## Files

- Browse Yiru materials: [Yiru/](Yiru/)

## External links

- Hal (2022-2023): https://drive.google.com/file/d/1P4oNZSKyOg9kB8Ie05srfcW8GpwyFp08/view?usp=sharing
