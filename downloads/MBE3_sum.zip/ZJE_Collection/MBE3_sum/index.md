# MBE3_sum

Files:

- [MBE Chromosome structure detection.md](MBE Chromosome structure detection.md)
- [MBE CRISPR screen disease gene factor.md](MBE CRISPR screen disease gene factor.md)
- [MBE CRISPR_screen_drug_resistence.md](MBE CRISPR_screen_drug_resistence.md)
- [MBE DNA assessment.md](MBE DNA assessment.md)
- [MBE Epigenetic sequencing.md](MBE Epigenetic sequencing.md)
- [MBE Epigenome Engineering Discussion.md](MBE Epigenome Engineering Discussion.md)
- [MBE Gene editing.md](MBE Gene editing.md)
- [MBE Gene expression analysis technologies.md](MBE Gene expression analysis technologies.md)
- [MBE mRNA visualization and analysis technologies.md](MBE mRNA visualization and analysis technologies.md)
- [MBE Protein assessment.md](MBE Protein assessment.md)
- [MBE Protein-DNA interaction.md](MBE Protein-DNA interaction.md)
- [MBE RNA assessment.md](MBE RNA assessment.md)
- [MBE RNA editing-based RNA-seq.md](MBE RNA editing-based RNA-seq.md)
- [MBE RNA-seq.md](MBE RNA-seq.md)
