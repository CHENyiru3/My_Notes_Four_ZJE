# BG2_sum

Files:

- [calculation.pdf](calculation.pdf)
- [Collection of disease.pdf](Collection of disease.pdf)
- [Collection of technology.pdf](Collection of technology.pdf)
