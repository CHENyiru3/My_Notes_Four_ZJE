# BG2_sum

## Contributors

- Yiru: [notes and PDFs](Yiru/index.md)

## Files

- Browse Yiru materials: [Yiru/](Yiru/)
