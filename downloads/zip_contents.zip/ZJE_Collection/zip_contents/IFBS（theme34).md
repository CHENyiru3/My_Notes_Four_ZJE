# Contents of IFBS（theme34).zip

Download: hosted externally (see the Google Drive folder linked from [Zips Index](../ZIPS_INDEX.md)).

- IFBS/IFBS theme3_消化吸收过程.pdf
- IFBS/IFBS theme3_消化器官1.pdf
- IFBS/IFBS theme3_消化系统2.pdf
- IFBS/IFBS theme4（非完整）.pdf
