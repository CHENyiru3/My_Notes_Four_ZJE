# Contents of MBE_lxrwyalxf.zip

Download: hosted externally (see the Google Drive folder linked from [Zips Index](../ZIPS_INDEX.md)).

- MBE/Key points - tp lxr.docx
- MBE/Key points-简化版关键信息.docx
- MBE/Techniques整理-lxr.docx
- MBE/课上SAQ.docx
