# IID_4_full

Files:

- [NotebookLLM_Topic_1.pdf](NotebookLLM_Topic_1.pdf)
- [NotebookLLm_Topic_3.pdf](NotebookLLm_Topic_3.pdf)
- [NotebookLLM_Topic_4.pdf](NotebookLLM_Topic_4.pdf)
- [NotebookLLM_Topic_5_EVA.pdf](NotebookLLM_Topic_5_EVA.pdf)
- [Topic 0 basic concept of immunology.md](Topic 0 basic concept of immunology.md)
- [Topic 1 Innate Immune system.md](Topic 1 Innate Immune system.md)
- [Topic 1.5 Trained Innate Immunity.md](Topic 1.5 Trained Innate Immunity.md)
- [Topic 10 what I need to know for exam.md](Topic 10 what I need to know for exam.md)
- [Topic 11 Macrophage.md](Topic 11 Macrophage.md)
- [Topic 12 Diseases.md](Topic 12 Diseases.md)
- [Topic 2 Inflammation algorithm.md](Topic 2 Inflammation algorithm.md)
- [Topic 3 T-Cell.md](Topic 3 T-Cell.md)
- [Topic 4 ILC, Innate lymphoid cells.md](Topic 4 ILC, Innate lymphoid cells.md)
- [Topic 5 B cell.md](Topic 5 B cell.md)
- [Topic 6 Auto-immune disease.md](Topic 6 Auto-immune disease.md)
- [Topic 7 System exhaustion and cytokine storms.md](Topic 7 System exhaustion and cytokine storms.md)
- [Topic 8 Immunometablism.md](Topic 8 Immunometablism.md)
- [Topic 9 monoclonal antibodies.md](Topic 9 monoclonal antibodies.md)
