# Year 1

Courses (Year 1):

- CHEM1: [CHEM1/](../CHEM1/)
- IBI1: [IBI1/](../IBI1/)
- IBMS1: [IBMS1/](../IBMS1/)
- ICMB1: [ICMB1/](../ICMB1/)
- MATH1: [MATH1/](../MATH1/)
