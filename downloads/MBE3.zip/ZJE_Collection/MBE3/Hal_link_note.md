Note: Hal zip link added to parent index.md
