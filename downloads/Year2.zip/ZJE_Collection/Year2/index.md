# Year 2 Courses

[Back to main page](../index.md)

## Available Courses

| | |
|---|---|
| [ADS2](../ADS2/) | Applied Data Science |
| [BG2](../BG2/) | Biochemistry |
| [BaO2](../BaO2/) | Biology of Organs |
| [DST2](../DST2/) | Data Science Tools |
| [GP2](../GP2/) | Genetics & Programming |
| [IFBS2](../IFBS2/) | Integrated Foundations |
| [MI2](../MI2/) | Microbiology |
