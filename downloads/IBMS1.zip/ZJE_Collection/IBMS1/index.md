# IBMS1

## External links

- Hal (2021-2022): https://drive.google.com/file/d/1lDYh5ghRXBE8z3et_ShQg3WCjwoq7egi/view?usp=sharing
