# Code Cheatsheet

This folder contains short cheat-sheets and summaries for common programming tasks.

Yiru's files:

- [base-r-cheat-sheet.pdf](Yiru/base-r-cheat-sheet.pdf)
- [data-visualization.pdf](Yiru/data-visualization.pdf)
- [JAVA_Sum_yiru.pdf](Yiru/JAVA_Sum_yiru.pdf)
- [java-cheat-sheet-comprehensive-guide.pdf](Yiru/java-cheat-sheet-comprehensive-guide.pdf)
- [R数据科学 ( etc.) (Z-Library).pdf](Yiru/R数据科学 %28 etc.%29 %28Z-Library%29.pdf)
- [SQL-cheat-sheet.pdf](Yiru/SQL-cheat-sheet.pdf)
