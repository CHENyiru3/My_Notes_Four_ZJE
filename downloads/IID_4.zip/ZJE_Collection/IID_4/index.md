# IID_4

## Contributors

- Yiru: [notes](Yiru/index.md)

## Files

- Browse Yiru notes: [Yiru/](Yiru/)

## External links

- Hal (2024-2025): https://drive.google.com/file/d/1croWrQe1agk-zbvIklNjL-roso30TlZ_/view?usp=sharing
