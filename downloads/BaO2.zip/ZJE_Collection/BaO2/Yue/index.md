# BaO2 — Yue

Materials contributed by Yue:

- BaO（非完整）.pdf — [Download/view](BaO（非完整）.pdf)

If you prefer a URL-safe filename, I can rename the PDF to `BaO_partial.pdf` and update links.
