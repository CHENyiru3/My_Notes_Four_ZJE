# CHEM (Chemistry)

## Contributors

- Hal (2021-2022): External materials available

## Notes & Materials

*This course currently has limited materials. Contributions welcome!*

## External Resources

- [Hal's Materials (2021-2022)](https://drive.google.com/file/d/12qrRLagEU9GqZkHguhvcXjDtLmpt5xw9/view?usp=sharing)
