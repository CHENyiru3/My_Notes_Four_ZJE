# CHEM

## External links

- Hal (2021-2022): https://drive.google.com/file/d/12qrRLagEU9GqZkHguhvcXjDtLmpt5xw9/view?usp=sharing
